<?php

echo "Bizarre bizarre, j'ai l'impression que tu t'es perdu :(";

?>